/**
 * This file is for a reusable grouping of Theme items.
 * Similar to an XML fragment layout in Android
 */
import EStyleSheet from 'react-native-extended-stylesheet';

// import FontHelper from '../helpers/FontHelper';

// import Colors from './Colors';
// import Colors from './Colors';

export default EStyleSheet.create({
  rootContainer: { flex: 1 }
});
